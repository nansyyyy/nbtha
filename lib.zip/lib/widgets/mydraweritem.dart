import 'package:flutter/material.dart';

class MyDrawerItem extends StatelessWidget {
  const MyDrawerItem({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}