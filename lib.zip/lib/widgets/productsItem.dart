import 'package:application5/controller/cont/product_controller.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:get/get.dart';

class ProductItemsWidget extends StatelessWidget{
   ProductItemsWidget({
    super.key
  });
  final controller = Get.put(ProductController());
  @override
  Widget build(BuildContext context) {
    return Obx(() => Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(241, 252, 243, 1),
        toolbarHeight: 70,
        leading: IconButton(
          onPressed: () {},
          icon: Icon(
            Icons.menu,
            color: Color.fromRGBO(24, 79, 39, 1),
            size: 34,
            shadows: [Shadow(color: Color.fromRGBO(217, 217, 217, 1))],
          ),
        ),
        actions: [
          Container(
            margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
            width: 46,
            height: 49,
            decoration: BoxDecoration(
              color: Color.fromRGBO(241, 252, 243, 1),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Color.fromARGB(255, 146, 158, 147).withOpacity(.4),
                  spreadRadius: 1,
                  blurRadius: 10,
                  offset: Offset(0, 3),
                )
              ],
            ),
            child: IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.search,
                size: 35,
                color: Color.fromRGBO(24, 79, 39, 1),
              ),
            ),
          )
        ],
      ),
      body: Column(
        children: [
          SizedBox(height: 20),
          Container(
            padding: EdgeInsets.only(left: 57),
            alignment: Alignment.topLeft,
            child: Text(
              "Categories",
              
              style: GoogleFonts.workSans(
                color: Color.fromRGBO(24, 79, 39, 1),
                fontSize: 25,
                letterSpacing: -0.24,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          SizedBox(height: 9,),
          Expanded(
            child: CustomScrollView(
              slivers: [
                SliverFillRemaining(
                  hasScrollBody: true,
                  child: Container(
                    padding: EdgeInsets.all(15),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(40),
                        topRight: Radius.circular(40),
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Column(
                  children: [
                  
                    Container(
                      child: MaterialButton(onPressed: (){
                        // Get.to(Seedlings());
                       
                      },),
                      width: 95,
                      height: 95,
                      decoration: BoxDecoration(
                         image: DecorationImage(image: AssetImage("images/seedlings.jpg"), fit: BoxFit.fill),
                        borderRadius: BorderRadius.circular(15),
                        
                      ),
                    ),
                    SizedBox(height: 10,),
                    Text("Seedlings", style: GoogleFonts.workSans(
                color: Color.fromRGBO(26, 116, 49, 1),
                fontSize: 17,
                letterSpacing: -0.24,
                fontWeight: FontWeight.w500,),)
                  ],
                ),
                Column(
                  children: [
                    Container(
                         child: MaterialButton(onPressed: (){
                        // Get.to(FarmingTools());
                      },),
                      width: 95,
                      height: 95,
                      decoration: BoxDecoration(
                        image: DecorationImage(image: AssetImage("images/tools.jpg"), fit: BoxFit.fill),
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Text("Farming Tools", style: GoogleFonts.workSans(
                color: Color.fromRGBO(26, 116, 49, 1),
                fontSize: 17,
                letterSpacing: -0.24,
                fontWeight: FontWeight.w500,),),
                  ],
                ),
                Column(
                  children: [
                    Container(
                         child: MaterialButton(onPressed: (){
                        // Get.to(Fertilizer());
                       
                      },),
                      width: 95,
                      height: 95,
                      decoration: BoxDecoration(
                        image: DecorationImage(image: AssetImage("images/fert.jpg"), fit: BoxFit.fill),
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Text("Fertilizer", style: GoogleFonts.workSans(
                color: Color.fromRGBO(26, 116, 49, 1),
                fontSize: 17,
                letterSpacing: -0.24,
                fontWeight: FontWeight.w500,),),
                  ],
                ),
              ],
            ),
                         
                        SizedBox(height: 30),
                        Container(
                          padding: EdgeInsets.only(left: 18)
                          ,child: Text("All Products",
                             style: GoogleFonts.workSans(
                color: Color.fromRGBO(24, 79, 39, 1),
                fontSize: 21,
                letterSpacing: -0.24,
                fontWeight: FontWeight.w500,
              ),)),
                        SizedBox(
                          height: 400,
                          child: Obx(() => GridView.builder(
                            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              mainAxisSpacing: 58,
                              crossAxisSpacing: 78,
                            ),
                            itemCount: controller.productlist.length,
                            
                            itemBuilder: (context, i) {
                              return
                               Container(
                         
                               
                                height: 150,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xffD9D9D9), width: 1),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(10),
                                    topRight: Radius.circular(10),
                                  ),
                                  
                                ),
                                child: Column(
                                  
                                 
                                  children: [
                                    // Container(
                                      
                                    //   child: CachedNetworkImage(
                                    //     imageUrl: controller.toolsList[i]["img"],
                                    //     placeholder: (context, url) => CircularProgressIndicator(),
                                    //     errorWidget: (context, url, error) => Icon(Icons.error),
                                    //     height: 89,
                                    //     width: 135,


                                    //     // fit: BoxFit.fitWidth,
                                    //   ),
                                    // ),
                                    
                                      Text(
                                        
                                        textAlign: TextAlign.start,
                                        "${controller.productlist[i]["name"]}",
                                        style: GoogleFonts.workSans(
                                                      color: Color.fromRGBO(30, 155, 61, 1),
                                                   fontSize: 18,
                                                      letterSpacing: -2.24,
                                                      fontWeight: FontWeight.w400,
                                                     
                                                      
                                                    ),
                                      ),
                                    
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Text(
                                         
                                          "${controller.productlist[i]["price"]}",
                                          style: GoogleFonts.workSans(
                                                        color: Color.fromRGBO(30, 155, 61, 1),
                                                        fontSize: 2,
                                                        letterSpacing: -2.24,
                                                        fontWeight: FontWeight.w400,
                                                        
                                                      ),
                                        ),
                                        // Container(
                                         
                                       
                                          
                                        //   decoration: BoxDecoration(
                                        //     color: Color.fromRGBO(241, 252, 243, 1),
                                        //     borderRadius: BorderRadius.circular(100)
                                            
                                           
                                        //   ),
                                        //   child: Row(
                                        //     mainAxisAlignment: MainAxisAlignment.spaceAround,
                                        //     mainAxisSize: MainAxisSize.min,
                                            
                                        //     children: [
                                        //       IconButton(
                                                
                                        //     onPressed: (){controller.remove();}, icon: Icon(Icons.remove), padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 18.0),iconSize: 12,)
                                        //       ,
                                        //       Obx(()=> Text('${controller.value}',
                                        //       style: TextStyle(
                                        //         fontSize: 12,
                                        //         color: Colors.black

                                        //       )
                                        //        ) ),

                                        //        IconButton(
                                                
                                        //     onPressed: (){controller.add();}, icon: Icon(Icons.add), padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 18.0),iconSize: 12,)
                                          
                                        //     ],
                                        //   ),
                                        // )
                                      ],
                                    ),
                                        
                                    
                                  ],
                                ),
                              );
                            },
                          )),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ));
  }
}

