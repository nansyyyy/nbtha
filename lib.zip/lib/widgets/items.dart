// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';

// class ItemsWidgets extends StatelessWidget {
//   const ItemsWidgets({super.key, required this.image, required this.name});
//   final String image;
//   final String name;


//   @override
//   Widget build(BuildContext context) {
//     return  
//   }
// }