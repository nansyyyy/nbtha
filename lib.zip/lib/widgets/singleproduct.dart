// import 'package:agri/model/productModel.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/widgets.dart';

// class SingleProductWidget extends StatelessWidget {
//   final ProductModel product;
//   const SingleProductWidget({Key key, this.product}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }