import 'package:application5/controller/constant/imgs.dart';
import 'package:application5/controller/cont/product_controller.dart';
import 'package:application5/pages/seedlings.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:google_fonts/google_fonts.dart';

class Store extends StatelessWidget {
  Store({Key? key}) : super(key: key);

  final controller = Get.put(ProductController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizedBox(height: 20),
          Container(
            padding: EdgeInsets.only(left: 57),
            alignment: Alignment.topLeft,
            child: Text(
              "Categories",
              style: GoogleFonts.workSans(
                color: Color.fromRGBO(24, 79, 39, 1),
                fontSize: 25,
                letterSpacing: -0.24,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          SizedBox(
            height: 9,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Column(
                children: [
                  Container(
                    child: MaterialButton(
                      onPressed: () {
                        Get.to(()=>Seedlings());
                      },
                    ),
                    width: 95,
                    height: 95,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(seedling), fit: BoxFit.fill),
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Seedlings",
                    style: GoogleFonts.workSans(
                      color: Color.fromRGBO(26, 116, 49, 1),
                      fontSize: 17,
                      letterSpacing: -0.24,
                      fontWeight: FontWeight.w500,
                    ),
                  )
                ],
              ),
              Column(
                children: [
                  Container(
                    child: MaterialButton(
                      onPressed: () {
                        // Get.to(FarmingTools());
                      },
                    ),
                    width: 95,
                    height: 95,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(Tools), fit: BoxFit.fill),
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Farming Tools",
                    style: GoogleFonts.workSans(
                      color: Color.fromRGBO(26, 116, 49, 1),
                      fontSize: 17,
                      letterSpacing: -0.24,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    child: MaterialButton(
                      onPressed: () {
                        // Get.to(Fertilizer());
                      },
                    ),
                    width: 95,
                    height: 95,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                          image: AssetImage(fertilizer), fit: BoxFit.fill),
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    "Fertilizer",
                    style: GoogleFonts.workSans(
                      color: Color.fromRGBO(26, 116, 49, 1),
                      fontSize: 17,
                      letterSpacing: -0.24,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: 30),
          SingleChildScrollView(
            child: Column(
              children: [
                Container(
                    padding: EdgeInsets.only(left: 18),
                    child: Text(
                      "All Products",
                      style: GoogleFonts.workSans(
                        color: Color.fromRGBO(24, 79, 39, 1),
                        fontSize: 21,
                        letterSpacing: -0.24,
                        fontWeight: FontWeight.w500,
                      ),
                    )),


                SizedBox(
                  height: 428,
                  child: Obx(() {
                    return GridView.builder(
                      shrinkWrap: true,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 48,
                        crossAxisSpacing: 58,
                      ),
                      itemCount: controller.productlist.length,
                      itemBuilder: (context, i) {
                        return Container(
                          margin: EdgeInsets.all(10),
                          height: 150,
                          decoration: BoxDecoration(
                            border:
                                Border.all(color: Color(0xffD9D9D9), width: 1),
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Container(
                                child: CachedNetworkImage(
                                  imageUrl: controller.productlist[i]["img"],
                                  placeholder: (context, url) =>
                                      CircularProgressIndicator(),
                                  errorWidget: (context, url, error) =>
                                      Icon(Icons.error),
                                  height: 89,
                                  width: 135,

                                  // fit: BoxFit.fitWidth,
                                ),
                              ),
                              Text(
                                "${controller.productlist[i]["name"]}",
                                style: GoogleFonts.workSans(
                                  color: Color.fromRGBO(30, 155, 61, 1),
                                  fontSize: 18,
                                  letterSpacing: -2.24,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              Text(
                                "${controller.productlist[i]["price"]}",
                                style: GoogleFonts.workSans(
                                  color: Color.fromRGBO(30, 155, 61, 1),
                                  fontSize: 18,
                                  letterSpacing: -2.24,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  // Text(
                                  //   "${controller.seedlingsList[i]["cat"]}",
                                  //   style: GoogleFonts.workSans(
                                  //     color: Color.fromRGBO(30, 155, 61, 1),
                                  //     fontSize: 2,
                                  //     letterSpacing: -2.24,
                                  //     fontWeight: FontWeight.w400,
                                  //   ),
                                  // ),

                                  
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    );
                  }),
                ),
              ],
            ),
          )

         
        ],
      ),
    );
  }
}
