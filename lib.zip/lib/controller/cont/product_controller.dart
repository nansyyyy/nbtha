import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

class ProductController extends GetxController {
  final productlist = [].obs;
  final seedlingsList = [].obs;
  final FertilizersList = [].obs;
  final Farming_toolsList = [].obs;

  void getProduct() async {
    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance.collection("Agrimarket").get();
      
      
      productlist.addAll(querySnapshot.docs);
    } catch (e) {
      print("Error getting productlist: $e");
    }
  }
  // void getSeedlings() async {
  //   try {
  //     QuerySnapshot querySnapshot =
  //         await FirebaseFirestore.instance.collection("Agrimarket").where("cat",isEqualTo: "Seedlings").get();

      
  //     productlist.addAll(querySnapshot.docs);
  //   } catch (e) {
  //     print("Error getting seedlingsList: $e");
  //   }
  // }
  // void getFertilizers() async {
  //   try {
  //     QuerySnapshot querySnapshot =
  //         await FirebaseFirestore.instance.collection("Agrimarket").where("cat",isEqualTo: "Fertilizers").get();

      
  //     FertilizersList.addAll(querySnapshot.docs);
  //   } catch (e) {
  //     print("Error getting FertilizersList: $e");
  //   }
  // }
  // void getFarming_tools() async {
  //   try {
  //     QuerySnapshot querySnapshot =
  //         await FirebaseFirestore.instance.collection("Agrimarket").where("cat",isEqualTo: "Farming Tools").get();

      
  //     Farming_toolsList.addAll(querySnapshot.docs);
  //   } catch (e) {
  //     print("Error getting Farming_toolsList: $e");
  //   }
  // }
    
  @override
  void onInit() {
    getProduct();
    super.onInit();
  }
}
