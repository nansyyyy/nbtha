
const String SplashImg = "images/img1.jpeg";
const String SplashImg2 = "images/img2.png";

//onBoarding images
const String on1 = "images/on1.png";
const String on2 = "images/on2.png";
const String on3 = "images/on3.png";
const String on11 = "images/on11.jpeg";

// store images
const String seedling ="images/seedling.png";
const String Tools ="images/farmingtools.png";
const String fertilizer ="images/fertilizer.png";

const String logo = "images/logo.png";