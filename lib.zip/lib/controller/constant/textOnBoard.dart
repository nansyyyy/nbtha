

const String title = "Scan Your Plant";
const String subtitle = "Start scanning your plant for disease identification and treatment.";
const String title1 ="Join to community";
const String subtitle1= "Participation in a Preferred Community: Facilitating Agricultural Discussion, Inquiry, and Experience Sharing";
const String title2="Track the progress of your plant's life cycle";
const String subtitle2="Through tips and weather alerts features";
